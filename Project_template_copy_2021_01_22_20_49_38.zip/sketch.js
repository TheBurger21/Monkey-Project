function setup() {
  createCanvas(600, 600);
  var bg= createSprite(300,200,700,400);
bg.setAnimation("bg");


var monkey=createSprite(100,300,10,10);
monkey.setAnimation("monkey");
monkey.scale=0.25;

var ground=createSprite(200,380,400,20);
ground.visible=false;

var survivalTime=0;
stroke("black");
textSize(20);
fill("black");
survivalTime=Math.ceil(frameCount/frameRate());
text("Survival Time: " + survivalTime,100,50);


var BananaGroup=createGroup();
var ObstacleGroup=createGroup();

}

function draw() {
spawnObstacles;
  spawnBanana;
  
  monkey.collide(ground);
  bg.velocityX=2;
  if(bg.x>=250){
    bg.x=200;
  }
 if(keyDown("space") && monkey.y >= 275){
      monkey.velocityY = -12 ;
    }
  
    
    monkey.velocityY = monkey.velocityY + 0.8;
    
 
  drawSprites();
}

function spawnObstacles() {
  if(World.frameCount % 60 === 0) {
    var obstacle = createSprite(400,365,10,40);
    
    
    //generate random obstacles
   
    obstacle.setAnimation("obstacle");
    
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.5;
    obstacle.lifetime = -1;
    //add each obstacle to the group
    ObstacleGroup.add(obstacle);
  }
}

function spawnBanana() {
  //write code here to spawn the clouds
  if (World.frameCount % 80 === 0) {
    var banana = createSprite(400,320,40,10);
    banana.y = randomNumber(280,320);
    banana.setAnimation("banana");
    banana.scale = 0.5;
    banana.velocityX = -3;
    
    banana.lifetime=-1;
     //assign lifetime to the variable
    
    
    //adjust the depth
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    //add each cloud to the group
    BananaGroup.add(banana);
  }
}
